document.getElementById('esquecisenhaForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('email').value;

    if (email) {
        fetch('/esquecisenha', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email })
        })
        .then(response => {
            if (response.ok) {
                const confirmationMessage = document.getElementById('confirmationMessage');
                confirmationMessage.style.display = 'block';
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 3000); // Redireciona após 3 segundos
            } else {
                alert('Erro ao enviar email de redefinição de senha.');
                window.location.href = 'login.html'; // Redireciona em caso de erro
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao enviar email de redefinição de senha.');
            window.location.href = 'login.html'; // Redireciona em caso de erro
        });
    } else {
        alert("Por favor, preencha o campo de email.");
    }
});
